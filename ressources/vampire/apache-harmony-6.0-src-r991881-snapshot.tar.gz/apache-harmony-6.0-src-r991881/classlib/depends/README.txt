The 'depends' directory  contains compile-time and
package-time dependencies only.
