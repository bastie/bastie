The 'modules' directory contains Java source files and manifest files
stored under the <class library component>/src and
<class library component>/META-INF respectively.
